package com.itvedant.sketchbookingsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.itvedant.sketchbookingsystem.dao.RegisterUserDAO;
import com.itvedant.sketchbookingsystem.entity.User;
import com.itvedant.sketchbookingsystem.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	public User registerUser(RegisterUserDAO registerUserDAO) {
		
		// Check if email has used already by any user or Not
		if(this.userRepository.findByEmail(
					registerUserDAO.getEmail()).isPresent()
				) {
			throw new ResponseStatusException(
						HttpStatus.BAD_REQUEST, 
						"User is already register with this Email."
					);
		}
		
		User user = new User();
		
		user.setFirst_name(registerUserDAO.getFirst_name());
		user.setLast_name(registerUserDAO.getLast_name());
		user.setEmail(registerUserDAO.getEmail());
		user.setPassword(passwordEncoder.encode(registerUserDAO.getPassword()));
		user.setMobile(registerUserDAO.getMobile());
		user.setRoles(registerUserDAO.getRoles());
		
		this.userRepository.save(user);
		
		return user;
	}
}
