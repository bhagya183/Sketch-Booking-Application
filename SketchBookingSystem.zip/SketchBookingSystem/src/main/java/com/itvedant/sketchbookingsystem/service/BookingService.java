package com.itvedant.sketchbookingsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itvedant.sketchbookingsystem.dao.AddBookingDAO;
import com.itvedant.sketchbookingsystem.entity.Artist;
import com.itvedant.sketchbookingsystem.entity.Booking;
import com.itvedant.sketchbookingsystem.entity.Sketch;
import com.itvedant.sketchbookingsystem.entity.User;
import com.itvedant.sketchbookingsystem.repository.ArtistRepository;
import com.itvedant.sketchbookingsystem.repository.BookingRepository;
import com.itvedant.sketchbookingsystem.repository.SketchRepository;
import com.itvedant.sketchbookingsystem.repository.UserRepository;

@Service
public class BookingService {
	
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ArtistRepository artistRepository;
	
	@Autowired
	private SketchRepository sketchRepository;
	
	
	public Booking createBooking(AddBookingDAO addBookingDAO) {
		
		User user = this.userRepository.findById(addBookingDAO.getUser_id()).orElse(null);
		
		Artist artist = this.artistRepository.findById(addBookingDAO.getArtist_id()).orElse(null);
		
		Sketch sketch = this.sketchRepository.findById(addBookingDAO.getSketch_id()).orElse(null);
		
		Booking booking = new Booking();
		
		booking.setStatus(addBookingDAO.getStatus());
		booking.setTotal_price(sketch.getPrice() * addBookingDAO.getQuantity());
		booking.setQuantity(addBookingDAO.getQuantity());
		booking.setUser(user);
		booking.setArtist(artist);
		booking.setSketch(sketch);
		
		
		this.bookingRepository.save(booking);
		
		return booking;
	}
}
