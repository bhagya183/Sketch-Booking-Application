package com.itvedant.sketchbookingsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.itvedant.sketchbookingsystem.dao.AddSketchDAO;
import com.itvedant.sketchbookingsystem.dao.UpdateSketchDAO;
import com.itvedant.sketchbookingsystem.service.SketchService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/sketches")
public class SketchController {

	@Autowired
	SketchService sketchService;
	
	// Add Sketches
	@PostMapping("")
	public ResponseEntity<?> create(@RequestBody @Valid AddSketchDAO addSketchDAO){
		return ResponseEntity.ok(this.sketchService.createSketch(addSketchDAO));
	}
	
	// Read All Sketches
	@GetMapping("")
	public ResponseEntity<?> readAll(){
		return ResponseEntity.ok(this.sketchService.readAllSketches());
	}
	
	// View (Read) by Id
	@GetMapping("/{id}")
	public ResponseEntity<?> readById(@PathVariable Integer id){
		return ResponseEntity.ok(this.sketchService.readBySketchId(id));
	}
	
	// Delete Sketch
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable Integer id){
		return ResponseEntity.ok(this.sketchService.deleteSketch(id));
	}
	
	// Update Sketch
	@PutMapping("/{id}")
	public ResponseEntity<?> update(@RequestBody UpdateSketchDAO updateSketchDAO, @PathVariable Integer id){
		return ResponseEntity.ok(this.sketchService.updateSketch(updateSketchDAO, id));
	}
	
	@PostMapping("/{id}/upload")
	public ResponseEntity<?> upload(@PathVariable Integer id, @RequestParam("file") MultipartFile file){
		return ResponseEntity.ok(this.sketchService.storeFile(id, file));
	}
	
	//For Downloading Images
	@GetMapping("/download/{filename}")
	public  ResponseEntity<?> download(@PathVariable String filename){
		
		Resource resource = this.sketchService.loadAsResource(filename);
		
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
					
					"attachment; filename=\"" + filename + "\"").body(resource);	
	}
	
	
	
	
}
