package com.itvedant.sketchbookingsystem.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.itvedant.sketchbookingsystem.FileProperties;
import com.itvedant.sketchbookingsystem.dao.AddSketchDAO;
import com.itvedant.sketchbookingsystem.dao.UpdateSketchDAO;
import com.itvedant.sketchbookingsystem.entity.Sketch;
import com.itvedant.sketchbookingsystem.exception.StorageException;
import com.itvedant.sketchbookingsystem.repository.SketchRepository;

@Service
public class SketchService {

	@Autowired
	SketchRepository sketchRepository;
	
	private final Path rootlocation;
	
	public SketchService(FileProperties fileProperties) {
		this.rootlocation = Paths.get(fileProperties.getUploadDir());
	
	
		try {
			//Convert into directory
			Files.createDirectories(rootlocation);
		}catch(IOException e) {
			
			throw new StorageException("Could not initialize directory.");
		}
		
	}
	
	public String storeFile(Integer id, MultipartFile file) {
		
		try {
			if(file.isEmpty()) {
				throw new StorageException("File is Empty.");
			}
			
			Path destinationFile = this.rootlocation.resolve(file.getOriginalFilename());
			
			try(InputStream inputStream = file.getInputStream()){
				
				Files.copy(inputStream, destinationFile, StandardCopyOption.REPLACE_EXISTING);
			}
			
			Sketch sketch = this.sketchRepository.findById(id).orElseThrow(
					
					()-> {
						throw new StorageException("Sketch with id" + id + "not Found.");
					}
					
				);
			
			String fileUploadDir = ServletUriComponentsBuilder
										.fromCurrentContextPath()
										.path("/sketches/download/")
										.path(file.getOriginalFilename())
										.toUriString();
			
			sketch.setImage_url(fileUploadDir);
			
			this.sketchRepository.save(sketch);
			
			return "File Uploaded.";
		}catch(IOException e) {
			throw new StorageException("File could not be saved");
		}
	}
	
	//download Images
public Resource loadAsResource (String fileName) {
		
		Path file = rootlocation.resolve(fileName);
		
		try {
			
			Resource resource = new UrlResource(file.toUri());
			
			if(resource.exists() && resource.isReadable()) {
				
				return resource;
				
			}else {
				
				throw new StorageException("Could not read file");
				
			}
			
		} catch(MalformedURLException e) {
			
			throw new StorageException("Could not read file");
			
		}
		
	}
		
	// add Sketches
	public Sketch createSketch(AddSketchDAO addSketchDAO) {
		
		Sketch sketch = new Sketch();
		
		sketch.setSketch_name(addSketchDAO.getSketch_name());
		sketch.setDescription(addSketchDAO.getDescription());
		sketch.setPrice(addSketchDAO.getPrice());
		
		this.sketchRepository.save(sketch);
		
		return sketch;
	}
	
	// view(Read) All Sketches
	public List<Sketch> readAllSketches(){
		
		List<Sketch> sketch = new ArrayList<Sketch>();
		
		sketch = this.sketchRepository.findAll();
		
		return sketch;
		
	}
	
	// View (Read) by Id
	public Sketch readBySketchId(Integer id) {
		
		Sketch sketch = new Sketch();
		
		sketch = this.sketchRepository.findById(id).orElse(null);
		
		return sketch;
	}
	
	// Delete Sketch
	public String deleteSketch(Integer id) {
		
		Sketch sketch =  this.readBySketchId(id);
		
		this.sketchRepository.delete(sketch);
		
		return "Sketch Data is Deleted.";
	}
	
	// Update Sketch
	public Sketch updateSketch(UpdateSketchDAO updateSketchDAO, Integer id) {
		
		Sketch sketch = this.readBySketchId(id);
		
		if(updateSketchDAO.getSketch_name() != null) {
			sketch.setSketch_name(updateSketchDAO.getSketch_name());
		}
		if(updateSketchDAO.getDescription() != null) {
			sketch.setDescription(updateSketchDAO.getDescription());
		}
		if(updateSketchDAO.getPrice() != null) {
			sketch.setPrice(updateSketchDAO.getPrice());
		}
		
		this.sketchRepository.save(sketch);
		
		return sketch;
		
		
	}
	
	
}
