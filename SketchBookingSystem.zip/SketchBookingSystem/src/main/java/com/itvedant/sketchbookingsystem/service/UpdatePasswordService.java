package com.itvedant.sketchbookingsystem.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.itvedant.sketchbookingsystem.dao.ChangePasswordDAO;
import com.itvedant.sketchbookingsystem.dao.CheckOTPDAO;
import com.itvedant.sketchbookingsystem.dao.SendEmailDAO;
import com.itvedant.sketchbookingsystem.entity.User;
import com.itvedant.sketchbookingsystem.repository.UserRepository;

@Service
public class UpdatePasswordService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private JavaMailSender emailSender;
	
	Random random = new Random();
	
	int otp = 0;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	public User updatePassword(ChangePasswordDAO changePasswordDAO, String email) {
		
		User user = new User();
		
		user = this.userRepository.findByEmail(email).orElse(null);
		
		if(changePasswordDAO.getPassword().equals(changePasswordDAO.getConfirmPassword())) {
			
			user.setPassword(passwordEncoder.encode(changePasswordDAO.getPassword()));
		}else {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Password & Confirm Password does Not Matched.");
		}
		
		this.userRepository.save(user);
		
		return user;
		
	}
	
	public String sendEmail(SendEmailDAO sendEmailDAO) {
		
		if(this.userRepository.findByEmail(sendEmailDAO.getEmail()).isPresent()) {
			
			SimpleMailMessage message = new SimpleMailMessage();
			
			otp = random.nextInt(10000);
			
			message.setFrom("bhagyashri18399@gmail.com");
			message.setTo(sendEmailDAO.getEmail());
			message.setSubject("OTP Verification!!!");
			message.setText("OTP is : " + this.otp);
			emailSender.send(message);
			
			return "Email Send!";
			
			
		}else {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "This email is not Registered.");
			
		}
		
	}
	
	
	public String checkOTP(CheckOTPDAO checkOTPDAO) {
		
		if(this.otp == checkOTPDAO.getOtp()) {
			
			return "OTP Matched.";
			
		}else {
			
			return "OTP Not Matched.";
			
		}
	}
	
}
