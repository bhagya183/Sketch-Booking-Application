package com.itvedant.sketchbookingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
@EnableConfigurationProperties({FileProperties.class})
public class SketchBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SketchBookingSystemApplication.class, args);
	}

}
