package com.itvedant.sketchbookingsystem.exception;

public class StorageException extends RuntimeException {

	//Constructor
	public StorageException(String message) {
		
		//Parent class Constructor
		super(message);
	}
}
