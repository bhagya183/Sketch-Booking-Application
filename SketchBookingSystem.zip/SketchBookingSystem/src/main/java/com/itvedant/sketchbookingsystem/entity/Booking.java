package com.itvedant.sketchbookingsystem.entity;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.data.rest.core.annotation.RestResource;

import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;

@Entity
@EntityListeners(AuditingEntityListener.class)
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	private String status;
	private Integer quantity;
	private Integer total_price;
	
	@CreatedDate
	private LocalDateTime booking_date;
	
	@LastModifiedDate
	private LocalDateTime deadline;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	@RestResource(path = "BookingsUser", rel = "user")
	private User user;
	
	@ManyToOne
	@JoinColumn(name = "artist_id")
	@RestResource(path = "BookingsArtist", rel = "artist")
	private Artist artist;
	
	 @ManyToOne
	 @JoinColumn(name = "sketch_id") // Foreign key to Sketch table
	 @RestResource(path = "BookingSketch", rel = "sketch")
	 private Sketch sketch;
	 
	 public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
		

	public Artist getArtist() {
		return artist;
	}

	public void setArtist(Artist artist) {
		this.artist = artist;
	}

	public Sketch getSketch() {
		return sketch;
	}

	public void setSketch(Sketch sketch) {
		this.sketch = sketch;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getTotal_price() {
		return total_price;
	}

	public void setTotal_price(Integer total_price) {
		this.total_price = total_price;
	}

	public LocalDateTime getBooking_date() {
		return booking_date;
	}

	public void setBooking_date(LocalDateTime booking_date) {
		this.booking_date = booking_date;
	}

	public LocalDateTime getDeadline() {
		return deadline;
	}

	public void setDeadline(LocalDateTime deadline) {
		this.deadline = deadline;
	}
	
	
	
}
