package com.itvedant.sketchbookingsystem.dao;

public class CheckOTPDAO {

	private Integer otp;

	public Integer getOtp() {
		return otp;
	}

	public void setOtp(Integer otp) {
		this.otp = otp;
	}
	
	
}
