package com.itvedant.sketchbookingsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itvedant.sketchbookingsystem.dao.ChangePasswordDAO;
import com.itvedant.sketchbookingsystem.dao.CheckOTPDAO;
import com.itvedant.sketchbookingsystem.dao.SendEmailDAO;
import com.itvedant.sketchbookingsystem.service.UpdatePasswordService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user/update_password")
public class UpdateUserController {

	@Autowired
	private UpdatePasswordService userPasswordService;
	
	@PutMapping("")
	public ResponseEntity<?> updatePassword(@RequestBody ChangePasswordDAO changePasswordDAO, HttpSession session){
		
		String email = (String) session.getAttribute("email");
		
		return ResponseEntity.ok(this.userPasswordService.updatePassword(changePasswordDAO, email));
	}
	
	@PostMapping("/email")
	public ResponseEntity<?> send(@RequestBody SendEmailDAO sendEmailDAO, HttpSession session){
		
		session.setAttribute("email", sendEmailDAO.getEmail());
		
		return ResponseEntity.ok(this.userPasswordService.sendEmail(sendEmailDAO));
	}
	
	@PostMapping("/check")
	public ResponseEntity<?> checkOTP(@RequestBody CheckOTPDAO checkOTPDAO){
		return ResponseEntity.ok(this.userPasswordService.checkOTP(checkOTPDAO));
	}
}
