package com.itvedant.sketchbookingsystem.dao;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class AddSketchDAO {

	@NotNull
	@Size(min = 3, message = "Sketch Name should at least contain 3 Character")
	private String sketch_name;
	
	@NotNull
	private String description;
	
	@NotNull
	private Integer price;
	
	public String getSketch_name() {
		return sketch_name;
	}
	public void setSketch_name(String sketch_name) {
		this.sketch_name = sketch_name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "AddSketchDAO [sketch_name=" + sketch_name + ", description=" + description + ", price=" + price
				+ "]";
	}
	
	
}
