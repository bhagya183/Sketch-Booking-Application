package com.itvedant.sketchbookingsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itvedant.sketchbookingsystem.dao.AddBookingDAO;
import com.itvedant.sketchbookingsystem.service.BookingService;

@Controller
@RequestMapping("/bookings")
public class BookingController {
	
	@Autowired
	private BookingService bookingService;
	
	@PostMapping("")
	public ResponseEntity<?> create(@RequestBody AddBookingDAO addBookingDAO){
		return ResponseEntity.ok(this.bookingService.createBooking(addBookingDAO));
	}
}
