package com.itvedant.sketchbookingsystem.dao;

public class AddBookingDAO {

	private String status;
	private Integer total_price;
	private Integer quantity;
	
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	// Foreign Key
	private Integer user_id;
	private Integer artist_id;
	private Integer sketch_id;
	
	
	
	public Integer getSketch_id() {
		return sketch_id;
	}
	public void setSketch_id(Integer sketch_id) {
		this.sketch_id = sketch_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getTotal_price() {
		return total_price;
	}
	public void setTotal_price(Integer total_price) {
		this.total_price = total_price;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public Integer getArtist_id() {
		return artist_id;
	}
	public void setArtist_id(Integer artist_id) {
		this.artist_id = artist_id;
	}
	
	
}
