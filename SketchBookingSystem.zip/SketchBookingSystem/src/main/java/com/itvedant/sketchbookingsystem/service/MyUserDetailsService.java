package com.itvedant.sketchbookingsystem.service;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.itvedant.sketchbookingsystem.entity.User;
import com.itvedant.sketchbookingsystem.repository.UserRepository;

@Service
public class MyUserDetailsService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		return this.userRepository.findByEmail(username).map(
					user-> {
						return new User(
									user.getEmail(),
									user.getPassword(),
									user.getRoles().stream().map(
												role-> new SimpleGrantedAuthority(role)
											).collect(Collectors.toList())
								);
					}
				).orElseThrow(
							()->{
								throw new UsernameNotFoundException("User with this email not found");
							}
						);
	}
	
	@Autowired
	private UserRepository userRepository;
	
	
}
